/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domaci;

/**
 *
 * @author stefan
 */
public class Kanta extends Valjak {
    
    private float k;
    
    /* k - kolicina tecnosti */
    
    public Kanta (float r, float h, float k) {
        super(r, h);
        this.k=k;
    }
   
    public float dodavanjeTecnosti(float d) {
        k+=d;
        return k;
    }
    
    public String ispitivanjeKolicine() {
        if (k>0) {
            return "U kanti ima tecnosti!";
        }
        else
        {
            return "Kanta je prazna!";
        }
    }
    
    public String ispitivanjeKante() {
        return "Poluprecnik kante je: " + r + ". Visina kante je: " + h + ". Zapremina kante je: " + zapremina() + ". " + ispitivanjeKolicine();
        
    }
}
