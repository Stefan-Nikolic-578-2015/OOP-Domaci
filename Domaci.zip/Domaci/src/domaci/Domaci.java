/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domaci;

import java.util.Scanner;

/**
 *
 * @author stefan
 */
public class Domaci {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Unesite poluprecnik valjka: ");
        float r = scan.nextFloat();
        System.out.println("Unesite visinu valjka: ");
        float h = scan.nextFloat();
        Valjak valjak = new Valjak(r,h);
        
        System.out.println("Unesite poluprecnik kante: ");
        float r_ = scan.nextFloat();
        System.out.println("Unesite visinu kante: ");
        float h_ = scan.nextFloat();
        System.out.println("Unesite kolicinu tecnosti u kanti: ");
        float k = scan.nextFloat();
        Kanta kanta = new Kanta(r_, h_, k);
        
        System.out.println(valjak.ispitivanjeValjka());
        System.out.println(kanta.ispitivanjeKante());
        
        System.out.println("Da li zelite da dodate tecnost u kantu? (Ako zelite ukucajte 'Da')");
        scan.nextLine();
        String s = scan.nextLine();
        if (s.equals("Da")) {
            System.out.println("Koliko?");
            float d = scan.nextFloat();
            k=kanta.dodavanjeTecnosti(d);
            System.out.println(k);
            System.out.println(kanta.ispitivanjeKante());        
        }
                       
        scan.close();
    }
    
}
