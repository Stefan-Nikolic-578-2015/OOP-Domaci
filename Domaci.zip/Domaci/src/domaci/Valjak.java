/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domaci;

/**
 *
 * @author stefan
 */
public class Valjak {

    public float h, r;
    
    /* h - visina
       r - poluprecnik */
    
    public Valjak (float r, float h) {
        this.r=r;
        this.h=h;
    }
    
    public float zapremina() {
        float v;
        float pi=3.14f;
        v=r*r*h*pi;
        return v;
    }
    
    public String ispitivanjeValjka() {
        return "Poluprecnik valjka je: " + r + ". Visina valjka je: " + h + ". Zapremina valjka je: " + zapremina() + ".";
    }
}

